from .models import Company, User, Catalog
from rest_framework import serializers


class CompanySerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = Company
        fields = ('name', 'phone_number')

class UserSerializer(serializers.HyperlinkedModelSerializer):
	company = CompanySerializer(read_only=True)
	class Meta:
	    model = User
	    fields = ('name','age','contact','email','doj','company')

class CatalogSerializer(serializers.HyperlinkedModelSerializer):
	company = CompanySerializer(read_only=True)
	total_price = serializers.SerializerMethodField('calculate_total_price')

	def calculate_total_price(self, catalog_obj) :
		return catalog_obj.no_of_pcs * catalog_obj.per_pcs_price

	class Meta:
	    model = Catalog
	    fields = ('name','no_of_pcs','per_pcs_price','company','total_price')