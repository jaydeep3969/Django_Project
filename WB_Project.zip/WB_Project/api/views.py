from django.shortcuts import render

from django.http import HttpResponse, Http404
from .models import Company, User, Catalog
from rest_framework.response import Response
from rest_framework import viewsets
from .serializers import CompanySerializer,UserSerializer, CatalogSerializer
from rest_framework.decorators import action

def index(request):
    return HttpResponse("Hello, world. You're using WB_API")

class CompanyViewSet(viewsets.ModelViewSet):
    queryset = Company.objects.all()
    serializer_class = CompanySerializer

    @action(methods=['get'], detail=True, url_path="catalogs")
    def get_catalogs(self, request, pk) :
    	queryset = Catalog.objects.filter(company=pk)
    	catalogs =  CatalogSerializer(queryset, many=True).data
    	return Response(catalogs)


class UserViewSet(viewsets.ModelViewSet):
    queryset = User.objects.all()
    serializer_class = UserSerializer

class CatalogViewSet(viewsets.ModelViewSet):
    queryset = Catalog.objects.all()
    serializer_class = CatalogSerializer
