from django.db import models
from django.core.validators import RegexValidator, validate_email

phone_no_regex =  RegexValidator(regex=r'^(\+91)?\d{10}$', message="Indian phone numbers are allowed only.")


class Company(models.Model):
    name = models.CharField('Company Name',max_length=50)
    phone_number = models.CharField(validators=[phone_no_regex], max_length=13, blank=True)


class User(models.Model):
    name = models.CharField('User Name',max_length=50)
    doj = models.DateTimeField('Date of Joining')
    age = models.IntegerField()
    email = models.EmailField(max_length = 50, blank = True, unique= True, validators = [validate_email])
    contact = models.CharField(validators=[phone_no_regex], max_length=13, blank=True)
    company = models.ForeignKey(Company, on_delete=models.CASCADE)


class Catalog(models.Model):
    name = models.CharField('Catalog Name',max_length=50)
    no_of_pcs = models.IntegerField(default=0)
    per_pcs_price = models.IntegerField(default=0)
    company = models.ForeignKey(Company, on_delete=models.CASCADE)
